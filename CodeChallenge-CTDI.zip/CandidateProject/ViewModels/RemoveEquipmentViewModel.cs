﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CandidateProject.ViewModels
{
    public class RemoveEquipmentViewModel
    {
        public int CartonId { get; set; }
        public int EquipmentId { get; set; }
    }
}